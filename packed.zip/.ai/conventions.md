# Conventions

- Event contracts: use record types in `NightmareV2.Contracts.Events`; include envelope metadata fields for every new event.
- Event publication:
  - Prefer preserving inbound `CorrelationId`.
  - Set `CausationId` from parent event `EventId` when available.
  - Set `Producer` to the emitting service (`command-center`, `gatekeeper`, `worker-*`).
- Queue state values currently remain string constants (`HttpRequestQueueState` static class). Transition to enum-backed state machine is planned.
- Maintenance/diagnostics safety:
  - Endpoint enable flags alone are insufficient.
  - When enabled, corresponding API key must be configured; otherwise endpoint reports misconfiguration.
- Event emitters in services should enqueue to `IEventOutbox` rather than calling MassTransit publish directly from domain/application flows.
- Consumers handling cross-service events should call `IInboxDeduplicator` early in `Consume` and short-circuit duplicate deliveries.
- CommandCenter route organization:
  - Register feature modules from `NightmareV2.CommandCenter.Endpoints` in `Program.cs`.
  - Keep route definitions out of `Program.cs` when a bounded context has more than trivial handlers.
- Enumeration conventions:
  - Queue enumeration via `SubdomainEnumerationRequested`; do not invoke provider binaries directly from `TargetCreated` consumers.
  - Implement each enumeration tool as its own `ISubdomainEnumerationProvider` and execute only the requested provider per message.
  - Emit provider provenance on `AssetDiscovered` as `DiscoveredBy=enum-worker:<provider>` with method details in `DiscoveryContext`.
