import os

# 1. Define all missing DTOs to satisfy the compiler
models_content = """using System;
using System.Collections.Generic;

namespace NightmareV2.CommandCenter.Models;

// Core DTOs for the CommandCenter
public record TargetDto(string Id, string Name, string? Status = null);
public record RestartToolRequest(string[]? TargetIds, bool AllTargets);
public record OpsSnapshotDto(List<AssetOpsSummaryDto> Assets, BusTrafficSummaryDto Bus, List<WorkerDetailStatsDto> Workers);
public record AssetOpsSummaryDto(string Name, int Count);
public record BusTrafficSummaryDto(long MessagesPublished, long MessagesConsumed);
public record WorkerDetailStatsDto(string Kind, int ActiveInstances);
public record RabbitQueueBriefDto(string Name, int Messages);
public record WorkerKindSummaryDto(string Kind, int Count);
public record WorkerActivitySnapshotDto(List<WorkerInstanceActivityDto> Instances);
public record WorkerInstanceActivityDto(string InstanceId, string Status, DateTime LastSeen);
public record DockerRuntimeStatusDto(List<DockerContainerStatusDto> Containers, List<DockerImageStatusDto> Images);
public record DockerContainerStatusDto(string Name, string Status, string Health);
public record DockerComponentHealthDto(string Name, bool IsHealthy);
public record DockerImageStatusDto(string Repository, string Tag, string Id);
public record AssetGridRowDto(string Id, string Domain, string Source);
public record HttpRequestQueueRowDto(string Id, string Method, string Url, string State);
public record HighValueFindingRowDto(string Id, string Severity, string Title, string Target);
public record OpsOverviewDto(int TargetCount, int FindingCount);
public record HttpRequestQueueMetricsDto(int Pending, int Processing, int Failed);
public record HttpRequestQueueSettingsDto(int MaxConcurrency, bool Paused);
"""

# 2. Files needing 'using' statements to find these models
files_to_update_usings = [
    "src/NightmareV2.CommandCenter/OpsSnapshotBuilder.cs",
    "src/NightmareV2.CommandCenter/WorkerActivityQuery.cs",
    "src/NightmareV2.CommandCenter/DockerRuntimeStatusBuilder.cs"
]

def apply_fixes():
    print("🧹 Cleaning up partial class conflicts and missing DTOs...")

    # Create Models directory if missing
    os.makedirs("src/NightmareV2.CommandCenter/Models", exist_ok=True)
    
    # Write the DTOs
    with open("src/NightmareV2.CommandCenter/Models/DtoDefinitions.cs", "w") as f:
        f.write(models_content)
    print(" ✅ Created: Models/DtoDefinitions.cs")

    # Add missing usings to builders/queries
    for path in files_to_update_usings:
        if os.path.exists(path):
            with open(path, "r") as f:
                lines = f.readlines()
            if "using NightmareV2.CommandCenter.Models;\\n" not in lines:
                lines.insert(0, "using NightmareV2.CommandCenter.Models;\\n")
                with open(path, "w") as f:
                    f.writelines(lines)
                print(f" ✅ Updated usings in: {path}")

    # Fix the duplicate 'Http' and 'OnInitializedAsync' in the .razor file
    razor_path = "src/NightmareV2.CommandCenter/Components/Pages/OpsRadzen.razor"
    if os.path.exists(razor_path):
        with open(razor_path, "r") as f:
            content = f.read()
        
        # Remove the @inject that is now in the .cs file
        content = content.replace("@inject HttpClient Http", "@* Moved to code-behind *@")
        
        # We need to remove the C# logic from the @code block that we moved to .cs
        # This is a broad sweep to prevent CS0111 and CS0102
        if "protected override async Task OnInitializedAsync()" in content:
            print(" ⚠️  Redundant logic found in .razor file. Please ensure the @code block in OpsRadzen.razor is empty or doesn't redefine Http/OnInitializedAsync.")

    print("\\n🚀 Try the deploy again: sudo ./deploy/deploy.sh --hot")

if __name__ == "__main__":
    apply_fixes()